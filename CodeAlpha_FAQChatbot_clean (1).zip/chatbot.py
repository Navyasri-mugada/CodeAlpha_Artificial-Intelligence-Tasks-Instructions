import re
import nltk
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

nltk.download("stopwords", quiet=True)
from nltk.corpus import stopwords

FAQS = [
    {"question": "What is artificial intelligence?", "answer": "Artificial Intelligence (AI) is the simulation of human intelligence in machines that are programmed to think, learn, and solve problems like humans."},
    {"question": "What is machine learning?", "answer": "Machine learning is a subset of AI where algorithms learn from data to make predictions or decisions without being explicitly programmed for each task."},
    {"question": "What is deep learning?", "answer": "Deep learning uses neural networks with many layers to learn complex patterns from large datasets. It powers image recognition, speech processing, and language models."},
    {"question": "What is natural language processing?", "answer": "NLP is a field of AI that enables computers to understand, interpret, and generate human language. It powers chatbots, translation tools, and sentiment analysis."},
    {"question": "What is a neural network?", "answer": "A neural network is a computing system inspired by the human brain. It consists of layers of connected nodes that learn by adjusting weights during training."},
    {"question": "What is the difference between AI and machine learning?", "answer": "AI is the broad concept of building intelligent machines. Machine learning is a method to achieve AI by training models on data instead of programming explicit rules."},
    {"question": "What is supervised learning?", "answer": "Supervised learning trains a model on labeled data where both inputs and correct outputs are provided. Examples include classification and regression tasks."},
    {"question": "What is unsupervised learning?", "answer": "Unsupervised learning finds hidden patterns in data without labeled outputs. Common techniques include clustering and dimensionality reduction."},
    {"question": "What is reinforcement learning?", "answer": "Reinforcement learning trains an agent to make decisions by rewarding correct actions and penalizing wrong ones. It is used in robotics and game playing."},
    {"question": "What is overfitting?", "answer": "Overfitting happens when a model memorizes training data including noise and performs poorly on new data. It can be reduced using regularization or more training data."},
    {"question": "What is a training dataset?", "answer": "A training dataset is the data used to teach a machine learning model. It is kept separate from the test set used to evaluate the model's performance."},
    {"question": "What is cross-validation?", "answer": "Cross-validation splits data into multiple folds, trains on some and tests on others, to give a reliable estimate of how well a model will generalize."},
    {"question": "What is the difference between classification and regression?", "answer": "Classification predicts a discrete category such as spam or not spam. Regression predicts a continuous value such as a house price."},
    {"question": "What is a large language model?", "answer": "A large language model is a deep learning model trained on massive text data to understand and generate human language. Examples include GPT and BERT."},
    {"question": "What Python libraries are used in AI?", "answer": "Common libraries are NumPy and Pandas for data handling, Scikit-learn for classical ML, TensorFlow and PyTorch for deep learning, and NLTK or SpaCy for NLP."},
    {"question": "What is TensorFlow?", "answer": "TensorFlow is an open-source machine learning framework developed by Google for building and deploying deep learning models at scale."},
    {"question": "What is PyTorch?", "answer": "PyTorch is an open-source deep learning framework developed by Meta. It is widely used in research due to its dynamic computation graph."},
    {"question": "What is data science?", "answer": "Data science is a field that uses statistics, programming, and domain knowledge to extract insights and knowledge from structured and unstructured data."},
    {"question": "What is a confusion matrix?", "answer": "A confusion matrix shows the counts of true positives, false positives, true negatives, and false negatives to evaluate a classification model's performance."},
    {"question": "What is feature engineering?", "answer": "Feature engineering is the process of selecting, transforming, or creating input variables to improve the performance of a machine learning model."},
]

STOP_WORDS = set(stopwords.words("english"))

def preprocess(text):
    text = text.lower()
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    tokens = [t for t in text.split() if t not in STOP_WORDS and len(t) > 1]
    return " ".join(tokens)

corpus = [preprocess(f["question"] + " " + f["answer"]) for f in FAQS]
vectorizer = TfidfVectorizer(ngram_range=(1, 2))
faq_matrix = vectorizer.fit_transform(corpus)

def get_answer(query):
    vec = vectorizer.transform([preprocess(query)])
    scores = cosine_similarity(vec, faq_matrix).flatten()
    best = scores.argmax()
    score = scores[best]
    if score < 0.05:
        return "Sorry, I don't have an answer for that. Try asking about AI, machine learning, or Python.", score
    return FAQS[best]["answer"], score

print("Chatbot is ready. Type 'quit' to exit.\n")
while True:
    user_input = input("You: ").strip()
    if not user_input:
        continue
    if user_input.lower() in ("quit", "exit"):
        print("Bot: Goodbye!")
        break
    answer, score = get_answer(user_input)
    print(f"Bot: {answer}\n")
