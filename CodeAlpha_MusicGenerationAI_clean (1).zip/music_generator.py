from music21 import stream, note, chord, tempo
import random
from collections import defaultdict

TRAINING_SEQUENCES = [
    ["C4","D4","E4","F4","G4","A4","B4","C5","B4","A4","G4","F4","E4","D4","C4"],
    ["C4","E4","G4","C5","G4","E4","C4","E4","G4","C5"],
    ["A3","B3","C4","D4","E4","F4","G4","A4","G4","F4","E4","D4","C4","B3","A3"],
    ["G4","A4","B4","C5","D5","E5","F5","G5","F5","E5","D5","C5","B4","A4","G4"],
    ["C4","D4","E4","G4","A4","C5","A4","G4","E4","D4","C4"],
    ["C4","E4","F4","G4","B4","C5","B4","G4","F4","E4","C4"],
    ["E4","G4","A4","C5","D5","C5","A4","G4","E4","G4","A4","B4","C5","B4","A4","G4","E4"],
    ["C4","G4","E4","G4","C4","G4","F4","A4","F4","A4","G4","B4","G4","B4","C5"],
]

NOTE_TO_MIDI = {"C":0,"D":2,"E":4,"F":5,"G":7,"A":9,"B":11}
CHORD_INTERVALS = {"major":[0,4,7],"minor":[0,3,7],"dim":[0,3,6]}

def train_markov(sequences, order=2):
    transitions = defaultdict(lambda: defaultdict(int))
    for seq in sequences:
        for i in range(len(seq) - order):
            context = tuple(seq[i:i+order])
            transitions[context][seq[i+order]] += 1
    return transitions

def predict_next(transitions, context, pool):
    candidates = transitions.get(context)
    if not candidates:
        return random.choice(pool)
    return random.choices(list(candidates.keys()), weights=list(candidates.values()), k=1)[0]

def note_to_midi(name):
    return NOTE_TO_MIDI[name[:-1]] + (int(name[-1]) + 1) * 12

def build_chord(root, chord_type="major"):
    intervals = CHORD_INTERVALS.get(chord_type, [0,4,7])
    root_midi = note_to_midi(root)
    name_map = {0:"C",2:"D",4:"E",5:"F",7:"G",9:"A",11:"B",
                1:"C#",3:"D#",6:"F#",8:"G#",10:"A#"}
    result = []
    for interval in intervals:
        midi = root_midi + interval
        result.append(f"{name_map.get(midi % 12, 'C')}{(midi // 12) - 1}")
    return result

def generate(transitions, pool, num_events=80, chord_prob=0.25, bpm=120, order=2):
    durations = [0.5, 1.0, 1.5, 2.0]
    music = stream.Stream()
    music.append(tempo.MetronomeMark(number=bpm))
    history = [random.choice(pool)] * order

    for _ in range(num_events):
        context = tuple(history[-order:])
        next_note = predict_next(transitions, context, pool)
        dur = random.choice(durations)

        if random.random() < chord_prob:
            chord_type = random.choice(["major", "minor", "dim"])
            notes = build_chord(next_note, chord_type)
            try:
                event = chord.Chord(notes)
                event.quarterLength = dur
                music.append(event)
            except:
                event = note.Note(next_note)
                event.quarterLength = dur
                music.append(event)
        else:
            event = note.Note(next_note)
            event.quarterLength = dur
            music.append(event)

        history.append(next_note)

    return music

note_pool = ["C4","D4","E4","F4","G4","A4","B4","C5","D5","E5","F5","G5"]

print("Training Markov model...")
transitions = train_markov(TRAINING_SEQUENCES, order=2)

print("Generating music...")
music = generate(transitions, note_pool, num_events=80, chord_prob=0.25, bpm=120)

music.write("midi", fp="generated_music.mid")
print("Done! Saved as generated_music.mid")
