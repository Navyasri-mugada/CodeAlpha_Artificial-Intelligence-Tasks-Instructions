import cv2
from ultralytics import YOLO

model = YOLO("yolov8n.pt")

cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("Webcam not found. Trying video file...")
    cap = cv2.VideoCapture("input_video.mp4")

if not cap.isOpened():
    print("Error: No video source found.")
    exit()

print("Object Detection & Tracking started.")
print("Press 'q' to quit.")

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    results = model.track(frame, persist=True, verbose=False)
    annotated = results[0].plot()

    boxes = results[0].boxes
    count = len(boxes) if boxes is not None else 0

    cv2.putText(annotated, f"Objects Detected: {count}", (10, 35),
                cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 255, 0), 2, cv2.LINE_AA)

    cv2.imshow("Object Detection & Tracking - YOLOv8", annotated)

    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()
