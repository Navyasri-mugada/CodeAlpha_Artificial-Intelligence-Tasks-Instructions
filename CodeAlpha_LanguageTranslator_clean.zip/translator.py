import requests

LANGUAGES = {
    "1": ("en", "English"),
    "2": ("hi", "Hindi"),
    "3": ("ta", "Tamil"),
    "4": ("te", "Telugu"),
    "5": ("ml", "Malayalam"),
    "6": ("kn", "Kannada"),
    "7": ("fr", "French"),
    "8": ("es", "Spanish"),
    "9": ("de", "German"),
    "10": ("ja", "Japanese"),
    "11": ("zh", "Chinese"),
    "12": ("ar", "Arabic"),
}

def show_languages():
    print("\nAvailable languages:")
    for key, (_, name) in LANGUAGES.items():
        print(f"  {key:>2}. {name}")
    print()

def pick_language(prompt):
    show_languages()
    while True:
        choice = input(prompt).strip()
        if choice in LANGUAGES:
            return LANGUAGES[choice]
        print("Invalid choice. Enter a number from the list.")

def translate(text, source_code, target_code):
    url = "https://api.mymemory.translated.net/get"
    params = {"q": text, "langpair": f"{source_code}|{target_code}"}
    response = requests.get(url, params=params, timeout=10)
    data = response.json()
    if data["responseStatus"] == 200:
        return data["responseData"]["translatedText"]
    raise Exception(data.get("responseDetails", "Translation failed"))

print("Language Translator")
print("=" * 40)

while True:
    text = input("\nEnter text to translate (or 'quit' to exit):\n> ").strip()
    if text.lower() in ("quit", "exit"):
        print("Goodbye!")
        break
    if not text:
        continue

    source_code, source_name = pick_language("Select source language number: ")
    target_code, target_name = pick_language("Select target language number: ")

    if source_code == target_code:
        print("Source and target languages must be different.")
        continue

    print(f"\nTranslating from {source_name} to {target_name}...")
    try:
        result = translate(text, source_code, target_code)
        print(f"\nTranslated Text:\n{result}\n")
    except Exception as e:
        print(f"Error: {e}")
